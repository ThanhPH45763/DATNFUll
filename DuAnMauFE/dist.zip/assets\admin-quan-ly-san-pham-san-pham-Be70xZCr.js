import{_ as a,c as e,o as n}from"./index-da-92GSY.js";const o={};function t(c,r,s,_,p,m){return n(),e("div")}const f=a(o,[["render",t]]);export{f as default};
