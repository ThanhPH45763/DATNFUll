const o="/assets/logo_GHTK-CbPjoG5R.png";export{o as _};
