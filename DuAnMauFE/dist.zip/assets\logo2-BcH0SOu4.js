const o="/assets/logo2-CLFtbzO9.png";export{o as l};
