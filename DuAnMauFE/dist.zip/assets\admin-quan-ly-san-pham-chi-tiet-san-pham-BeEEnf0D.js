import{_ as a,c as e,o as n}from"./index-da-92GSY.js";const t={};function o(c,r,s,_,i,p){return n(),e("div")}const d=a(t,[["render",o]]);export{d as default};
