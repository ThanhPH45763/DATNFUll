const s="/assets/logoGB-DFAhUsc0.png";export{s as _};
